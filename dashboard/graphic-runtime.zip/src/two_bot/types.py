"""Type definitions for the two-bot pipeline."""

from collections.abc import Callable
from dataclasses import dataclass, field
import re
from typing import Any


@dataclass
class RelatedSignal:
    """A bundle-grade fact about ANOTHER same-cycle event (Phase D).

    Attached to a StoryBundle so the writer can reference a *verifiable*
    cross-signal pattern. Carries only facts that already cleared the editorial
    gate for their own event — never prose, correlation, or causation.
    """

    event_id: str
    signal_kind: str
    where: str
    when: str
    headline_metric: dict[str, Any]
    country: str = ""
    acquisition_evidence: dict[str, Any] | None = None
    air_quality_evidence: dict[str, Any] | None = None

    def to_dict(self) -> dict:
        data = {
            "event_id": self.event_id,
            "signal_kind": self.signal_kind,
            "where": self.where,
            "when": self.when,
            "headline_metric": self.headline_metric,
            "country": self.country,
        }
        if self.acquisition_evidence is not None:
            data["acquisition_evidence"] = self.acquisition_evidence
        if self.air_quality_evidence is not None:
            data["air_quality_evidence"] = self.air_quality_evidence
        return data


@dataclass
class StoryBundle:
    """The intern's output. Pure facts; no editorial angles.

    First-build note (A1): ``historical_context`` is an empty dict in the
    first build. The full schema will be filled once real FIRMS distributions
    are computed in a follow-up PR.
    """

    signal_kind: str
    where: str
    when: str
    event_id: str
    headline_metric: dict[str, Any]
    current_facts: list[dict[str, Any]]
    historical_context: dict[str, Any] = field(default_factory=dict)
    raw_signal_dump: dict[str, Any] = field(default_factory=dict)
    # Phase D geo + cross-signal context. ``country`` is the canonical 2-letter
    # code used to window related signals (falls back to a current_facts entry
    # when a builder hasn't set it). ``related_signals`` rides in the USER prompt
    # via to_dict — never the cached WRITER_SYSTEM_PROMPT — so the prompt cache
    # is preserved and single-event behavior is byte-identical when empty.
    country: str = ""
    related_signals: list["RelatedSignal"] = field(default_factory=list)
    # Bet A (A1): sourced human-impact facts matched from the newsworthiness
    # lane. Each entry carries claim/value/source_name/url/as_of — the iron
    # constraint; the evidence contract blocks the writer on any entry missing
    # its warrant. Rides the USER prompt via to_dict (never the cached system
    # prompt); empty = today's behavior everywhere.
    human_impact: list[dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        from src.data.places import event_identity, country_key
        identity = event_identity(self.event_id)
        if identity:
            self.raw_signal_dump = {**self.raw_signal_dump, **identity}
            self.country = country_key(self.raw_signal_dump.get("country", self.country))

        from src.data.temperature_evidence import project_story_evidence
        project_story_evidence(self)

    def to_dict(self) -> dict:
        data: dict[str, Any] = {
            "signal_kind": self.signal_kind,
            "where": self.where,
            "when": self.when,
            "event_id": self.event_id,
            "headline_metric": self.headline_metric,
            "current_facts": self.current_facts,
            "historical_context": self.historical_context,
            "raw_signal_dump": self.raw_signal_dump,
        }
        # Omit when empty so single-event bundles serialize byte-identically
        # (flag OFF / no related signals == today's user prompt).
        if self.country:
            data["country"] = self.country
        if self.related_signals:
            data["related_signals"] = [r.to_dict() for r in self.related_signals]
        if self.human_impact:
            data["human_impact"] = self.human_impact
        return data


@dataclass
class MemorySlice:
    """The memory layer's contribution to the writer's context."""

    recent_tweets_same_country: list[str] = field(default_factory=list)
    recent_tweets_same_event: list[str] = field(default_factory=list)
    ongoing_event: dict | None = None
    used_era_anchors: list[str] = field(default_factory=list)
    used_peer_comparisons: list[str] = field(default_factory=list)
    used_framings: list[str] = field(default_factory=list)
    shipped_tweet_texts: list[str] = field(default_factory=list)
    recent_categories: list[str] = field(default_factory=list)
    # A common issuer report ID is weaker than a confirmed physical episode.
    source_report_series: dict | None = None

    def to_dict(self) -> dict:
        result = {
            "recent_tweets_same_country": self.recent_tweets_same_country,
            "recent_tweets_same_event": self.recent_tweets_same_event,
            "ongoing_event": self.ongoing_event,
            "used_era_anchors": self.used_era_anchors,
            "used_peer_comparisons": self.used_peer_comparisons,
            "used_framings": self.used_framings,
            "shipped_tweet_texts": self.shipped_tweet_texts,
            "recent_categories": self.recent_categories,
        }
        if self.source_report_series is not None:
            result["source_report_series"] = self.source_report_series
        return result


@dataclass
class WriterResult:
    """The writer's output."""

    tweet: str | None
    kill_reason: str | None
    angle_chosen: str
    era_anchor_used: str | None
    peer_comparison_used: str | None
    reasoning: str
    # Bet A (A1): the writer's self-report — True iff the tweet text carries a
    # bundle.human_impact fact. Requested only via the IMPACT_GUIDANCE user-
    # prompt rider, so it is None for every non-enriched draft. Advisory: a
    # regex sweep in save_draft cross-checks it (either signal forces
    # manual_only; a missing field on an enriched draft fails closed).
    cited_impact: bool | None = None
    # Local failed-call diagnostic, never an accepted provider output field.
    failure_diagnostic: dict | None = None
    kill_scope: str | None = None
    kill_code: str | None = None
    # Local provenance only; the provider cannot self-certify first-attempt status.
    initial_response: bool = False

    def __post_init__(self):
        if (self.tweet is None) == (self.kill_reason is None):
            raise ValueError(
                "WriterResult invariant violated: exactly one of tweet/kill_reason "
                "must be non-None"
            )

    def validate_model_output(self) -> None:
        """Validate newly generated output, without reinterpreting old memory."""
        if self.tweet is not None and (not isinstance(self.tweet, str) or not self.tweet.strip()):
            raise ValueError("WriterResult tweet must be nonempty text")
        if self.kill_reason is not None and (not isinstance(self.kill_reason, str) or not self.kill_reason.strip()):
            raise ValueError("WriterResult kill_reason must be nonempty text")
        if not isinstance(self.angle_chosen, str) or len(self.angle_chosen) > 80:
            raise ValueError("WriterResult angle_chosen must be bounded text")
        if self.tweet is not None and not re.fullmatch(r"[a-z][a-z0-9]*(?:_[a-z0-9]+)*", self.angle_chosen):
            raise ValueError("WriterResult angle_chosen must be a snake_case label")
        if not isinstance(self.reasoning, str) or len(self.reasoning) > 12000:
            raise ValueError("WriterResult reasoning must be bounded text")
        if self.cited_impact is not None and type(self.cited_impact) is not bool:
            raise ValueError("WriterResult cited_impact must be boolean or null")
        if self.kill_scope not in (None, "evidence", "style", "context", "unknown"):
            raise ValueError("WriterResult kill_scope is not recognized")
        if self.kill_code not in (None, "insufficient_evidence", "conflicting_evidence"):
            raise ValueError("WriterResult kill_code is not recognized")
        if self.tweet is not None and (self.kill_scope is not None or self.kill_code is not None):
            raise ValueError("A viable tweet cannot carry rejection metadata")
        if self.kill_scope != "evidence" and self.kill_code is not None:
            raise ValueError("Only evidence-scoped rejections may carry an evidence code")
        for name, anchor in (("era_anchor_used", self.era_anchor_used), ("peer_comparison_used", self.peer_comparison_used)):
            if anchor is not None and (not isinstance(anchor, str) or not anchor.strip() or self.tweet is None or anchor not in self.tweet):
                raise ValueError(f"WriterResult {name} must be an exact nonempty tweet substring or null")
        for value in (self.tweet, self.kill_reason, self.angle_chosen, self.reasoning):
            if value is not None:
                try:
                    value.encode("utf-8")
                except UnicodeError as exc:
                    raise ValueError("WriterResult text contains malformed Unicode") from exc

    def to_dict(self) -> dict:
        data: dict[str, Any] = {
            "tweet": self.tweet,
            "kill_reason": self.kill_reason,
            "angle_chosen": self.angle_chosen,
            "era_anchor_used": self.era_anchor_used,
            "peer_comparison_used": self.peer_comparison_used,
            "reasoning": self.reasoning,
        }
        # Omit when None so non-enriched drafts serialize byte-identically.
        if self.cited_impact is not None:
            data["cited_impact"] = self.cited_impact
        if self.failure_diagnostic is not None:
            data["failure_diagnostic"] = self.failure_diagnostic
        if self.kill_scope is not None:
            data["kill_scope"] = self.kill_scope
        if self.kill_code is not None:
            data["kill_code"] = self.kill_code
        return data


@dataclass
class ExtractedClaim:
    """One concrete claim extracted from tweet text by Stage 3.5."""

    text: str
    kind: str

    def to_dict(self) -> dict:
        return {"text": self.text, "kind": self.kind}


@dataclass
class FactCheckResult:
    passed: bool
    failures: list[str]
    raw_response: str
    extracted_claims: list[ExtractedClaim] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "failures": self.failures,
            "raw_response": self.raw_response,
            "extracted_claims": [c.to_dict() for c in self.extracted_claims],
        }


@dataclass(frozen=True)
class TriageCandidateBundle:
    """A scored bundle queued for the triage stage. Source runners build
    these and append to bot_state['_triage_queue']; the triage stage
    ranks/caps them and the survivors enter the writer pipeline.

    Carries all the arguments _try_two_bot_draft() needs so the writer
    call site stays unchanged.

    NOTE: This is distinct from src.editorial.candidates.CandidateBundle
    which is the voice-generator's multi-candidate evaluator type. This
    type is for the pre-LLM triage queue.
    """
    bundle: Any  # StoryBundle — use Any to avoid circular import
    score: Any   # EditorialScore — use Any to avoid circular import
    event_id: str
    source: str                 # source_key for telemetry
    review_context: dict        # for save_draft
    city: str                   # for city cooldown
    tweet_date: str             # for same-day dedup
    cooldown_exempt: bool       # for elite-signal bypass
    legacy_type: str            # for save_draft type field
    created_at: str             # iso8601 — used as triage tiebreaker
    draft_metadata: dict | None = None  # extra persisted draft fields
    # Optional zero-argument callable invoked by the drain step on successful
    # draft. Use for source-specific side effects that must only fire when a
    # draft actually ships (e.g. incrementing an annual count, updating a
    # last-seen tier). Defaults to None = no-op. NOT persisted (queue is
    # transient and never written to sqlite).
    on_draft_success: Callable[[], None] | None = None
    # Optional zero-argument predicate returning True when this candidate's annual
    # cap is already reached, re-evaluated against LIVE bot_state. The Phase C
    # refill loop calls it at admit time (after firing prior successes' callbacks
    # inline) so reaching deeper near a cap can't overshoot in-cycle — and it keys
    # the cap by the source's own logic (event-date year, per-index counter), which
    # a static legacy_type map can't. Defaults to None = uncapped.
    annual_cap_check: Callable[[], bool] | None = None


@dataclass
class CriticResult:
    """Second-pass editorial critic verdict.

    The critic runs after fact_check passes and acts as the final
    editorial gate before a draft enters the human-approval queue.
    Legacy construction stays PASS/KILL; S-22 adds optional REVISE and
    slate-selection metadata behind dark flags.
    """

    passed: bool
    kill_reason: str | None
    raw_response: str
    verdict: str = ""
    revise_instruction: str | None = None
    selected_index: int | None = None
    # Soft craft details (C2): never a verdict, factual pass or human rating.
    quality: dict[str, str] | None = None
    quality_note: str | None = None

    def __post_init__(self) -> None:
        if not self.verdict:
            self.verdict = "PASS" if self.passed else "KILL"
        self.verdict = self.verdict.upper()
        if self.verdict == "PASS":
            if not self.passed:
                raise ValueError(
                    "CriticResult invariant violated: PASS verdict requires passed=True"
                )
            if self.kill_reason is not None:
                raise ValueError(
                    "CriticResult invariant violated: kill_reason must be None when passed=True"
                )
            if self.revise_instruction is not None:
                raise ValueError(
                    "CriticResult invariant violated: revise_instruction must be None for PASS"
                )
            return
        if self.verdict == "KILL":
            if self.passed:
                raise ValueError(
                    "CriticResult invariant violated: KILL verdict requires passed=False"
                )
            if not self.kill_reason:
                raise ValueError(
                    "CriticResult invariant violated: kill_reason required when passed=False"
                )
            if self.revise_instruction is not None:
                raise ValueError(
                    "CriticResult invariant violated: revise_instruction must be None for KILL"
                )
            return
        if self.verdict == "REVISE":
            if self.passed:
                raise ValueError(
                    "CriticResult invariant violated: REVISE verdict requires passed=False"
                )
            if self.kill_reason is not None:
                raise ValueError(
                    "CriticResult invariant violated: kill_reason must be None for REVISE"
                )
            if not self.revise_instruction:
                raise ValueError(
                    "CriticResult invariant violated: revise_instruction required for REVISE"
                )
            if len(self.revise_instruction) > 200:
                raise ValueError(
                    "CriticResult invariant violated: revise_instruction exceeds 200 chars"
                )
            return
        raise ValueError(f"CriticResult invariant violated: unknown verdict {self.verdict!r}")

    def to_dict(self) -> dict:
        payload: dict[str, Any] = {
            "passed": self.passed,
            "kill_reason": self.kill_reason,
            "raw_response": self.raw_response,
            "verdict": self.verdict,
            "revise_instruction": self.revise_instruction,
        }
        if self.selected_index is not None:
            payload["selected_index"] = self.selected_index
        # Omitted when absent so legacy critic records serialize byte-identically.
        if self.quality is not None:
            payload["quality"] = dict(self.quality)
        if self.quality_note is not None:
            payload["quality_note"] = self.quality_note
        return payload
