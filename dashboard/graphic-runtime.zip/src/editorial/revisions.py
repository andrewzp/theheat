"""Bind editorial decisions to exact draft text and evidence.

The equivalent JavaScript contract lives in dashboard/lib/draft-revisions.js.
These fingerprints detect stale decisions; they are not a storage lock.
"""

from __future__ import annotations

from copy import deepcopy
from collections.abc import Mapping
from datetime import datetime, timezone
import hashlib
import json
import math
import struct
from typing import Any

from src.editorial.publication import automatic_publication_policy, valid_epoch


def _canonical(value: Any) -> Any:
    if value is None:
        return ["null"]
    if isinstance(value, bool):
        return ["boolean", value]
    if isinstance(value, (int, float)):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError("Revision evidence must contain finite numbers")
        # JSON numbers share one IEEE-754 representation across Python and JS.
        return ["number", struct.pack(">d", 0.0 if number == 0 else number).hex()]
    if isinstance(value, str):
        return ["string", value]
    if isinstance(value, list):
        return ["array", [_canonical(item) for item in value]]
    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        return ["object", [
            [key, _canonical(value[key])]
            for key in sorted(value, key=lambda key: key.encode("utf-8"))
        ]]
    raise ValueError("Revision evidence must be JSON data")


def fingerprint(value: Any) -> str:
    payload = json.dumps(_canonical(value), ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def text_hash(text: str) -> str:
    if not isinstance(text, str):
        raise ValueError("Draft text must be a string")
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _evidence_payload(draft: dict) -> dict:
    review = deepcopy(draft.get("review_context"))
    if isinstance(review, dict):
        two_bot = review.pop("two_bot", None)
        if isinstance(two_bot, dict) and "bundle" in two_bot:
            review["two_bot"] = {"bundle": two_bot["bundle"]}
    payload = {
        "event_id": draft.get("event_id"),
        "type": draft.get("type"),
        "tweet_date": draft.get("tweet_date"),
        "review_context": review,
        "hot10_rows": draft.get("hot10_rows"),
    }
    # Preserve every legacy identity; presence (even null) is new content.
    if "media_attachment" in draft:
        payload["media_attachment"] = deepcopy(draft["media_attachment"])
    return payload


def draft_identity(draft: dict) -> dict:
    revision = draft.get("content_revision", 0)
    if type(revision) is not int or not 0 <= revision <= 9007199254740991:
        raise ValueError("Invalid content revision")
    return {
        "content_revision": revision,
        "text_sha256": text_hash(draft.get("text", "")),
        "evidence_sha256": fingerprint(_evidence_payload(draft)),
    }


def decision_revision(draft: dict) -> int:
    revision = draft.get("decision_revision", 0)
    if type(revision) is not int or not 0 <= revision < 9007199254740991:
        raise ValueError("Invalid decision revision")
    return revision


def _advance_decision(draft: dict) -> None:
    draft["decision_revision"] = decision_revision(draft) + 1


def binding_matches(draft: dict, binding: Any) -> bool:
    if not isinstance(binding, dict):
        return False
    if type(binding.get("content_revision")) is not int:
        return False
    try:
        return all(binding.get(key) == value for key, value in draft_identity(draft).items())
    except (ValueError, TypeError, UnicodeError, OverflowError):
        return False


def _two_bot(draft: dict) -> dict:
    review = draft.get("review_context")
    value = review.get("two_bot") if isinstance(review, dict) else None
    return value if isinstance(value, dict) else {}


def _checks(two_bot: dict) -> dict:
    return {"fact_check": two_bot.get("fact_check"), "critic": two_bot.get("critic")}


def required_checks_fingerprint(value: Any) -> str | None:
    """Validate the structured receipt proof; it does not itself prove a pass."""
    import re
    fields = {"schema_version", "check_set_id", "candidate_id", "derivation_id", "checker_state_sha256", "completion_sha256", "stages"}
    stages = ("deterministic", "safety", "fact_check", "critic")
    if not isinstance(value, dict) or set(value) != fields or type(value["schema_version"]) is not int or value["schema_version"] != 1:
        return None
    def sha(item):
        return isinstance(item, str) and re.fullmatch(r"[0-9a-f]{64}", item) is not None
    if not all(sha(value[k]) for k in fields - {"schema_version", "stages"}):
        return None
    if not isinstance(value["stages"], dict) or set(value["stages"]) != set(stages):
        return None
    for stage in stages:
        row = value["stages"][stage]
        if not isinstance(row, dict) or set(row) != {"grant_id", "request_sha256", "observation_sha256", "receipt_sha256"} or not all(sha(v) for v in row.values()):
            return None
    return fingerprint(value)


def _proof_matches(two_bot: dict, binding: dict) -> bool:
    if "required_checks_binding" not in two_bot:
        return "required_checks_sha256" not in binding
    digest = required_checks_fingerprint(two_bot["required_checks_binding"])
    return digest is not None and digest == binding.get("required_checks_sha256")


def _checks_pass(two_bot: dict) -> bool:
    return all(
        isinstance(two_bot.get(key), dict) and two_bot[key].get("passed") is True
        for key in ("fact_check", "critic")
    )


_CURRENT_POLICY = object()


def _editorial_policy(value=_CURRENT_POLICY):
    from src.editorial.policy import current_editorial_policy, valid_policy
    if value is _CURRENT_POLICY:
        return current_editorial_policy()
    return value if valid_policy(value) else None


def _policy_matches(binding, policy):
    from src.editorial.policy import valid_policy
    try:
        stored = binding.get("editorial_policy")
        return valid_policy(policy) and valid_policy(stored) and fingerprint(stored) == fingerprint(policy) == binding.get("policy_sha256")
    except (ValueError, TypeError, UnicodeError, OverflowError):
        return False


def _valid_delegation(value) -> bool:
    # Provenance references, not signatures. The trusted caller verifies actual
    # user authorization and retains the referenced evidence before recording.
    return (isinstance(value, dict)
            and set(value) == {"scope", "reviewer", "authorization_sha256", "review_receipt_sha256"}
            and value["scope"] == "one_manual_post" and value["reviewer"] == "codex"
            and all(isinstance(value[k], str) and len(value[k]) == 64
                    and all(c in "0123456789abcdef" for c in value[k])
                    for k in ("authorization_sha256", "review_receipt_sha256")))


def review_is_current(draft: dict, *, policy=_CURRENT_POLICY) -> bool:
    # Text-only reviews cannot authorize an image or silently drop it at send.
    if "media_attachment" in draft:
        return False
    binding = draft.get("review_binding")
    if draft.get("revision_conflicts") or not isinstance(binding, dict) or not binding_matches(draft, binding):
        return False
    if not _policy_matches(binding, _editorial_policy(policy)):
        return False
    if binding.get("kind") == "human":
        return True
    if binding.get("kind") == "delegated":
        return _valid_delegation(binding.get("delegation"))
    if binding.get("kind") != "model" or not _checks_pass(_two_bot(draft)):
        return False
    try:
        return _proof_matches(_two_bot(draft), binding) and binding.get("checks_sha256") == fingerprint(_checks(_two_bot(draft)))
    except (ValueError, TypeError, UnicodeError, OverflowError):
        return False


def approval_is_current(draft: dict, mode: str | None = None, *, policy=_CURRENT_POLICY) -> bool:
    binding = draft.get("approval_binding")
    policy = _editorial_policy(policy)
    if not isinstance(binding, dict) or not review_is_current(draft, policy=policy) or not binding_matches(draft, binding) or not _policy_matches(binding, policy):
        return False
    if binding.get("mode") not in ("manual", "auto"):
        return False
    if mode and binding.get("mode") != mode:
        return False
    try:
        if type(binding.get("decision_revision")) is not int or binding["decision_revision"] != decision_revision(draft):
            return False
    except ValueError:
        return False
    try:
        if (draft["review_binding"].get("kind") == "delegated" or "review_binding_sha256" in binding) and (
            binding.get("review_binding_sha256") != fingerprint(draft["review_binding"])
        ):
            return False
    except (ValueError, TypeError, UnicodeError, OverflowError):
        return False
    if binding.get("publish_intent_id") != draft.get("publish_intent_id"):
        return False
    if binding["mode"] == "auto" and draft["review_binding"].get("kind") != "model":
        return False
    return True


def has_unresolved_publish(draft: dict, state: Mapping[str, Any]) -> bool:
    """Unknown attempts and receipts for other content cannot be cleared by edits."""
    ledger = state.get("publish_ledger") or {}
    event_id = draft.get("event_id") or draft.get("id")

    def unresolved(attempt: Any) -> bool:
        if not isinstance(attempt, dict):
            return True
        conflicts = attempt.get("attempt_conflicts", [])
        if not isinstance(conflicts, list):
            return True
        if any(unresolved(other) for other in conflicts):
            return True
        if attempt.get("tweet_id"):
            if "text_sha256" in attempt:
                return not binding_matches(draft, attempt)
            return isinstance(attempt.get("text"), str) and attempt["text"] != draft.get("text")
        # A missing phase is legacy evidence of a possible send, not proof of expiry.
        return attempt.get("phase") != "not_sent"

    # Missing evidence and an explicitly malformed retained row are different.
    # Never treat null/scalar conflict members as proof that nothing was sent.
    if isinstance(ledger, dict) and event_id in ledger and unresolved(ledger[event_id]):
        return True
    if draft.get("publish_outcome") in ("submitted", "unknown"):
        return True
    if draft.get("status") == "posted" or draft.get("publish_outcome") in ("not_sent", "confirmed"):
        return False
    return bool(draft.get("autoship_attempted") or draft.get("last_publish_attempt_at"))


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def record_model_review(draft: dict, *, policy=_CURRENT_POLICY, at: str | None = None) -> dict:
    return _record_model_review(draft, policy=policy, at=at, verified_required_checks=False)


def _record_verified_checks_review(draft: dict, *, policy: dict, at: str) -> dict:
    """Internal authority boundary, called only after retained-byte verification.

    Generic save/initialization deliberately cannot mint this receipt-backed
    authority from caller-supplied structured metadata.
    """
    return _record_model_review(draft, policy=policy, at=at, verified_required_checks=True)


def _record_model_review(draft: dict, *, policy, at, verified_required_checks: bool) -> dict:
    revoke_approval(draft)
    two_bot = _two_bot(draft)
    policy = _editorial_policy(policy)
    try:
        proven = (
            "media_attachment" not in draft
            and policy is not None
            and two_bot.get("reviewed_policy_sha256") == fingerprint(policy)
            and _checks_pass(two_bot)
            and two_bot.get("reviewed_text_sha256") == text_hash(draft.get("text", ""))
            and "bundle" in two_bot
            and two_bot.get("reviewed_bundle_sha256") == fingerprint(two_bot["bundle"])
        )
    except (ValueError, TypeError, UnicodeError, OverflowError):
        proven = False
    proof = required_checks_fingerprint(two_bot.get("required_checks_binding"))
    if "required_checks_binding" in two_bot and (proof is None or not verified_required_checks):
        proven = False
    if proven and not draft.get("revision_conflicts"):
        draft["review_binding"] = {
            **draft_identity(draft), "kind": "model", "reviewed_at": at if at is not None else _now(),
            "checks_sha256": fingerprint(_checks(two_bot)),
            "editorial_policy": deepcopy(policy), "policy_sha256": fingerprint(policy),
        }
        if proof is not None:
            draft["review_binding"]["required_checks_sha256"] = proof
    else:
        draft.pop("review_binding", None)
    return draft


def initialize_revision(draft: dict, *, at: str | None = None, policy=_CURRENT_POLICY) -> dict:
    draft.setdefault("content_revision", 1)
    return record_model_review(draft, at=at, policy=policy)


def record_human_review(draft: dict, *, at: str | None = None, policy=_CURRENT_POLICY) -> dict:
    if "media_attachment" in draft:
        raise ValueError("Joint media review is required; text-only review cannot approve this draft")
    if draft.get("revision_conflicts"):
        raise ValueError("Resolve the conflicting revision before reviewing")
    text = draft.get("text")
    if not isinstance(text, str) or not text.strip() or len(text) > 280:
        raise ValueError("Invalid draft text")
    policy = _editorial_policy(policy)
    if policy is None:
        raise ValueError("Editorial policy unverified; cannot establish a new review")
    draft["content_revision"] = max(1, draft_identity(draft)["content_revision"])
    revoke_approval(draft)
    draft["review_binding"] = {**draft_identity(draft), "kind": "human", "reviewed_at": at if at is not None else _now(),
                               "editorial_policy": deepcopy(policy), "policy_sha256": fingerprint(policy)}
    return draft


def record_delegated_review(draft: dict, *, authorization_sha256: str,
                            review_receipt_sha256: str, at: str | None = None,
                            policy=_CURRENT_POLICY) -> dict:
    """Trusted operator only: explicit user delegation, never a human rating.

    The caller retains and verifies both references. This does not authenticate
    a caller, validate factual claims, authorize automatic publishing or send.
    """
    delegation = {"scope": "one_manual_post", "reviewer": "codex",
                  "authorization_sha256": authorization_sha256,
                  "review_receipt_sha256": review_receipt_sha256}
    if not _valid_delegation(delegation):
        raise ValueError("Explicit delegated review provenance is required")
    # Reuse identical text/media/conflict/policy validation and revocation.
    # Only the completed delegated record is returned or persisted.
    record_human_review(draft, at=at, policy=policy)
    draft["review_binding"].update(kind="delegated", delegation=delegation)
    return draft


def authorize_draft(draft: dict, mode: str, intent_id: str | None = None, *, publication_epoch: str | None = None) -> dict:
    if not review_is_current(draft):
        raise ValueError("This revision needs revalidation")
    if mode not in ("manual", "auto"):
        raise ValueError("Invalid approval mode")
    if mode == "auto" and draft["review_binding"].get("kind") != "model":
        raise ValueError("Scheduling requires a current model review")
    if mode == "auto":
        policy = automatic_publication_policy()
        if not policy["enabled"] or (publication_epoch is not None and publication_epoch != policy["epoch"]):
            raise ValueError(policy["reason"])
        publication_epoch = policy["epoch"]
    return bind_reviewed_revision(draft, mode, at=_now(), intent_id=intent_id, publication_epoch=publication_epoch)


def bind_reviewed_revision(draft: dict, mode: str, *, at: str,
                           intent_id: str | None = None, publication_epoch: str | None = None, policy=_CURRENT_POLICY) -> dict:
    """Record a binding deterministically after the caller's authorization check.

    This is a domain transition, not permission to send a post. Runtime callers
    must use authorize_draft; a command authority supplies its verified policy
    and clock explicitly. Final publication still requires the sender's checks.
    """
    policy = _editorial_policy(policy)
    if not review_is_current(draft, policy=policy):
        raise ValueError("This revision needs revalidation")
    if mode not in ("manual", "auto"):
        raise ValueError("Invalid approval mode")
    if mode == "auto" and draft["review_binding"].get("kind") != "model":
        raise ValueError("Scheduling requires a current model review")
    if mode == "auto" and not valid_epoch(publication_epoch):
        raise ValueError("A valid publication epoch is required")
    _advance_decision(draft)
    draft["approval_binding"] = {
        **draft_identity(draft), "decision_revision": draft["decision_revision"],
        "mode": mode, "authorized_at": at,
        "editorial_policy": deepcopy(policy), "policy_sha256": fingerprint(policy),
    }
    if draft["review_binding"].get("kind") == "delegated":
        draft["approval_binding"]["review_binding_sha256"] = fingerprint(draft["review_binding"])
    if mode == "auto":
        draft["approval_binding"]["publication_epoch"] = publication_epoch
    if intent_id:
        draft["approval_binding"]["publish_intent_id"] = intent_id
        draft["publish_intent_id"] = intent_id
    return draft


def revoke_approval(draft: dict) -> dict:
    _advance_decision(draft)
    for key in (
        "approval_binding", "approved_at", "auto_approve_at", "auto_approve_requested_at",
        "publish_requested_at", "publish_intent_id", "autoship_on_critic_pass",
    ):
        draft.pop(key, None)
    draft["approval_mode"] = "manual"
    return draft


def invalidate_text(draft: dict, new_text: str, *, at: str | None = None) -> dict:
    if not isinstance(new_text, str) or not new_text.strip() or len(new_text) > 280:
        raise ValueError("Invalid draft text")
    text_hash(new_text)  # Reject malformed Unicode before changing durable fields.
    if new_text == draft.get("text") and not draft.get("revision_conflicts"):
        return draft
    _invalidate_content(draft, at=at)
    draft["text"] = new_text
    return draft


def invalidate_media_attachment(draft: dict, attachment: dict | None, *, at: str) -> dict:
    """Content transition only; callers qualify media and resolve current state.

    None removes a present attachment. This never records a joint review or
    authorizes transport, and existing text-only review paths refuse the field.
    """
    if attachment is not None and not isinstance(attachment, dict):
        raise ValueError("Media content must be an object")
    if attachment is None and "media_attachment" not in draft:
        return draft
    if attachment is not None:
        fingerprint(attachment)
        if "media_attachment" in draft:
            def encode(value):
                return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True)
            if encode(attachment) == encode(draft["media_attachment"]):
                return draft
    _invalidate_content(draft, at=at)
    if attachment is None:
        draft.pop("media_attachment", None)
    else:
        draft["media_attachment"] = deepcopy(attachment)
    return draft


def _invalidate_content(draft: dict, *, at: str | None = None) -> dict:
    previous = {key: deepcopy(draft[key]) for key in (
        "text", "review_context", "review_binding", "approval_binding", "revision_conflicts", "decision_revision",
        "media_attachment", "media_review_binding",
    ) if key in draft}
    previous.update(draft_identity(draft))
    if previous["content_revision"] >= 9007199254740991:
        raise ValueError("Content revision exhausted")
    if decision_revision(draft) >= 9007199254740990:
        raise ValueError("Decision revision exhausted")
    history = draft.get("revision_history", [])
    if not isinstance(history, list) or any(not isinstance(row, dict) for row in history):
        raise ValueError("Invalid revision history")
    previous["invalidated_at"] = at if at is not None else _now()
    draft.setdefault("revision_history", []).append(previous)
    draft["content_revision"] = previous["content_revision"] + 1
    draft["status"] = "pending"
    revoke_approval(draft)
    for key in ("review_binding", "media_review_binding", "revision_conflicts", "candidate_score", "selected_candidate_rank"):
        draft.pop(key, None)
    review = draft.get("review_context")
    if isinstance(review, dict) and isinstance(review.get("two_bot"), dict):
        review["two_bot"] = {key: value for key, value in review["two_bot"].items() if key in ("bundle", "signal_kind")}
    return draft


def project_draft(draft: dict, *, policy=_CURRENT_POLICY) -> dict:
    policy = _editorial_policy(policy)
    current = review_is_current(draft, policy=policy)
    return {
        **draft, "revision_identity": {**draft_identity(draft), "decision_revision": decision_revision(draft)},
        "review_status": "conflict" if draft.get("revision_conflicts") else "media_review_required" if "media_attachment" in draft else "policy_unverified" if policy is None else "passed" if current else "needs_revalidation",
        "review_kind": draft.get("review_binding", {}).get("kind") if current else None,
    }
